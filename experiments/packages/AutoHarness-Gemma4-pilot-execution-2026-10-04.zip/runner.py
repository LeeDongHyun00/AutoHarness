"""Pinned localhost-only pilot runner. Explicit preflight and run phases; no secrets."""
import argparse,fcntl,hashlib,json,os,time,urllib.request,platform,subprocess
from pathlib import Path
from jsonschema import Draft202012Validator
from protocol import canonical,inspect,feedback,make_request,schema_probe,strict
ROOT=Path(__file__).resolve().parent
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
def api(path,body=None,timeout=120):
 if path not in ['/lora-adapters','/apply-template','/tokenize','/v1/chat/completions/input_tokens','/v1/chat/completions']:raise ValueError('endpoint')
 req=urllib.request.Request('http://127.0.0.1:18090'+path,data=None if body is None else canonical(body),headers={'Content-Type':'application/json'})
 with OPENER.open(req,timeout=timeout) as response:return json.load(response)
def sha(b):return hashlib.sha256(b).hexdigest()
def atomic(path,obj):
 tmp=path.with_suffix('.tmp')
 with tmp.open('w') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
 fd=os.open(str(path.parent),os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
def verify_package():
 manifest=json.loads((ROOT/'manifest.json').read_text())
 for name,spec in manifest['files'].items():
  p=ROOT/name
  if p.stat().st_size!=spec['bytes'] or sha(p.read_bytes())!=spec['sha256']:raise ValueError('package_changed')
 return sha((ROOT/'manifest.json').read_bytes())
def runtime(config,out):
 lock=json.loads((out/'runtime-lock.json').read_text())
 model=config['model']
 expected={'repo':model['repo'],'revision':model['revision'],'llama_commit':model['llama_cpp_commit'],'context':4096,'lora':[],'thinking':False,'reasoning_budget':0,'chat_template_kwargs':{'enable_thinking':False}}
 for key,value in expected.items():
  if lock.get(key)!=value:raise ValueError('runtime_mismatch:'+key)
 if '11382' not in lock.get('server_version','') or '11fe02151' not in lock['server_version']:raise ValueError('engine_version')
 for key in ['model_sha256','server_sha256']:
  value=lock.get(key)
  if not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):raise ValueError('runtime_hash:'+key)
 return lock

def tokenize(req,call,timeout=120):
 prompt=call('/apply-template',req,timeout).get('prompt')
 if not isinstance(prompt,str):raise ValueError('template_response')
 ids=call('/tokenize',{'content':prompt,'add_special':True,'parse_special':True},timeout).get('tokens')
 n=call('/v1/chat/completions/input_tokens',req,timeout).get('input_tokens')
 if not isinstance(ids,list) or any(type(x)is not int for x in ids) or type(n)is not int or n!=len(ids):raise ValueError('tokenizer_mismatch')
 if n+req['max_tokens']+8>4096:raise ValueError('context_budget')
 return {'input_tokens':n,'token_ids_sha256':sha(canonical(ids)),'prompt_sha256':sha(prompt.encode()),'request_sha256':sha(canonical(req))}

def validate_response(response,checked,max_tokens):
 choice=response['choices'][0];raw=choice['message']['content'];usage=response['usage']
 if not isinstance(raw,str):raise ValueError('content_type')
 if type(usage.get('prompt_tokens'))is not int or usage['prompt_tokens']!=checked['input_tokens']:raise ValueError('observed_input_mismatch')
 if type(usage.get('completion_tokens'))is not int or not 0<=usage['completion_tokens']<=max_tokens:raise ValueError('observed_output_mismatch')
 return raw,usage,choice.get('finish_reason')

def generate(state,statefile,key,req,checked,call,timeout):
 # Reservation is durable before sending. Unknown outcomes cannot be replayed.
 if key in state['attempts']:
  rec=state['attempts'][key]
  if rec['status']!='completed':raise ValueError('unresolved_attempt:'+key)
  if rec['request_sha256']!=checked['request_sha256']:raise ValueError('request_changed')
  return rec
 if len(state['attempts'])>=290:raise ValueError('global_call_budget')
 rec={'status':'reserved','request_sha256':checked['request_sha256'],'input_tokens_preflight':checked['input_tokens'],'started_unix':time.time()}
 state['attempts'][key]=rec;atomic(statefile,state);start=time.monotonic()
 try:
  response=call('/v1/chat/completions',req,max(0.1,timeout))
  raw,usage,finish=validate_response(response,checked,req['max_tokens'])
  rec.update(status='completed',raw_text=raw,usage=usage,finish_reason=finish,seconds=time.monotonic()-start)
  atomic(statefile,state);return rec
 except Exception as exc:
  rec.update(status='ambiguous_or_protocol_failed',error_type=type(exc).__name__,seconds=time.monotonic()-start)
  atomic(statefile,state);raise

def run(out,phase,confirm=False,call=api):
 if phase not in ('preflight','run'):raise ValueError('phase')
 if not confirm:raise ValueError('explicit_confirmation_required')
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 with (out/'pilot.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  pack=json.loads((ROOT/'payload.json').read_text());config=pack['config'];rt=runtime(config,out)
  frozen={'package_manifest_sha256':verify_package(),'payload_sha256':sha((ROOT/'payload.json').read_bytes()),'runtime_lock':rt}
  sf=out/'checkpoint.json'
  state=json.loads(sf.read_text()) if sf.exists() else dict(frozen,status='NOT_RUN',attempts={},cells={},initial_preflight={},preflight_passed=False)
  if any(state.get(k)!=v for k,v in frozen.items()):raise ValueError('frozen_inputs_changed')
  if any(v['status']!='completed' for v in state['attempts'].values()):raise ValueError('unresolved_attempt_manual_review_required')
  state.setdefault('sessions',[]).append({'time_unix':time.time(),'python':platform.python_version(),'platform':platform.platform()})
  atomic(sf,state)
  if call('/lora-adapters',None,120)!=[]:raise ValueError('lora_loaded')
  cases={c['case_id']:c for c in pack['cases']};arms={a['id']:a for a in config['arms']}
  if phase=='preflight':
   # Every initial input is tokenized before the two public generation probes.
   for cell in pack['order']:
    key=cell['case_id']+'/'+cell['arm_id'];req=make_request(cases[cell['case_id']],arms[cell['arm_id']]);checked=tokenize(req,call)
    if key in state['initial_preflight'] and state['initial_preflight'][key]!=checked:raise ValueError('preflight_changed')
    state['initial_preflight'][key]=checked
   atomic(sf,state)
   for index in range(2):
    req,schema=schema_probe(index);checked=tokenize(req,call)
    rec=generate(state,sf,'schema-probe-'+str(index),req,checked,call,120)
    if rec['finish_reason']!='stop' or not Draft202012Validator(schema).is_valid(strict(rec['raw_text'])):raise ValueError('json_schema_probe_failed_no_fallback')
   state['preflight_passed']=True;state['status']='PREFLIGHT_PASSED';atomic(sf,state)
   return state
  if not state['preflight_passed']:raise ValueError('run_preflight_first')
  state['status']='RUNNING';atomic(sf,state)
  for cell in pack['order']:
   key=cell['case_id']+'/'+cell['arm_id']
   if key in state['cells']:continue
   # An unfinished cell after a process restart needs manual reconciliation; elapsed budget is unknown.
   if any(k.startswith(key+'/') for k in state['attempts']):raise ValueError('unfinished_cell_manual_review:'+key)
   if sum(v.get('seconds',0) for v in state['cells'].values())>=config['budget']['global_wall_seconds_cap']:raise ValueError('global_wall_budget')
   start=time.monotonic();case=cases[cell['case_id']];arm=arms[cell['arm_id']]
   req=make_request(case,arm);checked=tokenize(req,call)
   if checked!=state['initial_preflight'].get(key):raise ValueError('runtime_template_changed')
   elapsed=lambda:time.monotonic()-start
   if elapsed()>=120:raise ValueError('cell_preflight_timeout')
   first=generate(state,sf,key+'/initial',req,checked,call,120-elapsed());errors=inspect(first['raw_text'],case)
   final=first;stop='no_repair';repair=None
   if arm['bounded_repair'] and feedback(errors,arm):
    repair_req=make_request(case,arm,first['raw_text'],errors)
    if elapsed()>=120:stop='wall_budget'
    else:
     try:repair_checked=tokenize(repair_req,call,max(.1,120-elapsed()))
     except ValueError as exc:
      if str(exc)!='context_budget':raise
      stop='repair_context_budget';repair_checked=None
     if repair_checked is not None:
      if checked['input_tokens']+repair_checked['input_tokens']>6656:stop='repair_input_budget'
      elif first['usage']['completion_tokens']+384>768:stop='repair_output_budget'
      elif elapsed()>=120:stop='wall_budget'
      else:
       repair=generate(state,sf,key+'/repair',repair_req,repair_checked,call,120-elapsed());final=repair;stop='repaired_once'
   state['cells'][key]={'case_id':case['case_id'],'family_id':case['family_id'],'arm_id':arm['id'],'initial_attempt':key+'/initial','final_attempt':key+('/repair' if repair else '/initial'),'initial_public_errors':errors,'final_public_errors':inspect(final['raw_text'],case),'stop_reason':stop,'seconds':elapsed(),'input_tokens':first['usage']['prompt_tokens']+(repair['usage']['prompt_tokens'] if repair else 0),'output_tokens':first['usage']['completion_tokens']+(repair['usage']['completion_tokens'] if repair else 0),'repair_count':int(repair is not None)}
   atomic(sf,state);print(len(state['cells']),'/192',key,stop,flush=True)
  state['status']='COMPLETED';atomic(sf,state);return state
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['preflight','run']);p.add_argument('--out',required=True);p.add_argument('--confirm',action='store_true');a=p.parse_args();run(a.out,a.phase,a.confirm)
