# Gemma4 파일 선택 pilot 실행 전용 — NOT_RUN

24개 새 합성 문제(8 설계 가족 × 정상/경계/적대) × J/F/R 8조건 = initial192. R1 96셀에서 최대1회 repair이므로 repair<=96. 공개 JSON schema probe2 포함 generation<=290. experiment output<=110592, probe<=64, 전체<=110656 tokens. 실제 input/output 사용량을 checkpoint에 기록합니다. context4096, initial384+repair384, seed104/temp0/thinkingoff/noLoRA. 기존216 baseline의 output768과 직접 비교하지 않습니다.

본 자료는 제한된 pilot/dev입니다. 8가족은 의도적으로 구성한 소규모 과제 유형이며 192독립표본 또는 sealed holdout이 아닙니다. 정상·적대 조건은 같은 과제의 인용문 공격 변형이고 경계 조건은 작은 규칙/값 변화입니다. 모든 과제는 file ID 선택으로 8조건 비교가 가능하며 실제 파일 실행/수정/하네스 실행은 없습니다. 원래의 광범위 성능 향상 설계를 파일 선택 진단으로 좁혔습니다.

J=응답 JSON schema 강제(실제 지원 미확인; preflight2회 통과 필수), F=ID 선택 지시+enum(J1일 때)+공개 membership/path 검증, R=공개 계약 오류코드로 repair최대1회. F0에는 file gate 오류를 repair로 전달하지 않지만 평가자는 모든 조건의 file safety를 동일하게 측정합니다. repair는 정답/최종 숨김 테스트를 보지 않습니다. 의미가 틀려도 공개 계약을 만족하면 repair하지 않습니다.

노트북은 무료 Kaggle T4x2용입니다. 실행용 ZIP만 private input으로 올리고 INPUT_ZIP 경로를 수정하세요. owner ZIP은 모델 런타임에 올리지 않습니다. ALLOW_SETUP, RUN_PREFLIGHT, RUN_EXPERIMENT는 각각 기본False이며 순서대로 검토한 뒤 켭니다. RunAll로 본 실험을 시작하지 않습니다. 모델/엔진은 고정revision과 해시를 확인하며 credentials를 만들거나 설정하지 않습니다. CUDA 라이브러리 로딩 실패 시 자동 다른버전/유료환경 전환 없이 중단합니다.

CLI는 `python runner.py preflight --out /kaggle/working/gemma4-improvement-pilot-results --confirm` 이후 별도로 `python runner.py run --out ... --confirm`입니다. 실행 전에 runtime-lock.json은 notebook이 실제 모델/서버 bytes로 작성합니다. payload/패키지/runtime lock이 바뀌면 resume를 거부합니다. 완료셀만 건너뛰며 reserved/실패/중간셀은 수동조정 전 재전송하지 않습니다. localhost18090 이외 주소는 runner에 없습니다.

각셀은 초기 tokenize부터120초, 출력합계768, input합계6656, 최대2회입니다. 글로벌 cells wall 상한25200초(7시간); 실제 무료세션 지속을 보장하지 않습니다. tokenizer 요청은 생성호출 상한에 포함하지 않으며 시간에는 포함합니다. probes/setup 시간·토큰은 본실험 분모와 별도 기록합니다. HTTP timeout은 이미 진행된 생성의 취소를 보장하지 않아 ambiguous로 남기고 재전송하지 않습니다.

최종 checkpoint/서버로그/runtime-lock/GPU정보를 비공개 결과 ZIP으로 보존하고 평가자에게 전달하세요. 사용자 응답·원시출력은 Git 밖에서 보관합니다. 답안은 실행 패키지에 없지만 동일 작성자가 두패키지를 준비했으므로 access-sealed holdout은 주장하지 않습니다. 부모가 owner package를 GPU 환경에 마운트하지 않는 실제 분리를 담당합니다.
