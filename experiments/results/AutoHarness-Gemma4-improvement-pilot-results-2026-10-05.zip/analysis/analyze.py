"""Secondary descriptive analyses only. Reads model outputs as JSON; never executes them."""
import json,sys,statistics,hashlib,collections,csv,platform,importlib.metadata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'analysis'
sys.path.insert(0,str(ROOT/'scorer'))
from score import strip_outer_fence
from protocol import strict,inspect,safe_path
s=json.loads((OUT/'frozen-scores.json').read_text()); c=json.loads((ROOT/'complete/run-probe128/checkpoint.json').read_text());p=json.loads((ROOT/'scorer/payload-for-scoring.json').read_text());o=json.loads((ROOT/'scorer/oracles.json').read_text());old=json.loads((ROOT/'complete/preflight-v1/checkpoint.json').read_text())
rows=s['rows'];idx={(r['case_id'],r['arm_id']):r for r in rows};cases={x['case_id']:x for x in p['cases']};arms={}
for a,base in s['arms'].items():
 rs=[r for r in rows if r['arm_id']==a];sec=[r['seconds'] for r in rs]
 arms[a]={**base,'final_public_contract':sum(r['final']['public_contract'] for r in rs),'final_semantic_exact':sum(r['final']['semantic_exact'] is True for r in rs),'final_semantic_unassessable':sum(r['final']['semantic_exact'] is None for r in rs),'posthoc_public_contract':sum(r['posthoc_fence_diagnostic']['public_contract'] for r in rs),'mean_seconds':statistics.mean(sec),'sum_seconds':sum(sec),'total_tokens':sum(r['input_tokens']+r['output_tokens'] for r in rs)}
b=arms['J0F0R0']
for a,v in arms.items():
 v.update(token_ratio_vs_baseline=v['total_tokens']/b['total_tokens'],mean_latency_ratio_vs_baseline=v['mean_seconds']/b['mean_seconds'],p95_latency_ratio_vs_baseline=v['p95_seconds']/b['p95_seconds'])
paired=[]
for factor,pos in [('J',1),('F',3),('R',5)]:
 for a in arms:
  if a[pos]!='0':continue
  aa=a[:pos]+'1'+a[pos+1:];pairs=[(idx[cid,a],idx[cid,aa]) for cid in cases]
  paired.append({'factor':factor,'off':a,'on':aa,'n_case_labels':24,'strict_gains':sum(not x['strict_task_success'] and y['strict_task_success'] for x,y in pairs),'strict_losses':sum(x['strict_task_success'] and not y['strict_task_success'] for x,y in pairs),'strict_difference':sum(y['strict_task_success']-x['strict_task_success'] for x,y in pairs)/24,'posthoc_semantic_gains':sum(x['posthoc_fence_diagnostic']['semantic_exact'] is not True and y['posthoc_fence_diagnostic']['semantic_exact'] is True for x,y in pairs),'posthoc_semantic_losses':sum(x['posthoc_fence_diagnostic']['semantic_exact'] is True and y['posthoc_fence_diagnostic']['semantic_exact'] is not True for x,y in pairs),'total_token_ratio':arms[aa]['total_tokens']/arms[a]['total_tokens'],'mean_seconds_ratio':arms[aa]['mean_seconds']/arms[a]['mean_seconds']})
failures=[];fences=0;changed_repairs=0;post_unknown=[];objects={}
for r in rows:
 key=r['case_id']+'/'+r['arm_id'];rec=c['cells'][key];raw=c['attempts'][rec['final_attempt']]['raw_text'];clean=strip_outer_fence(raw);fences+=raw!=clean;obj=strict(clean);objects[key]=obj
 if r['repairs'] and raw!=c['attempts'][rec['initial_attempt']]['raw_text']:changed_repairs+=1
 if any(e in ('unknown_file_id','unsafe_path') for e in inspect(clean,cases[r['case_id']])):post_unknown.append(key)
 if r['arm_id']=='J1F0R0' and not r['strict_task_success']:failures.append({'case_id':r['case_id'],'task':cases[r['case_id']]['task'],'expected':o[r['case_id']],'actual':obj})
request_groups=collections.defaultdict(list)
for case in cases.values():
 inp={k:case[k] for k in ['task','catalog','untrusted_file_note','response_schema']};request_groups[json.dumps(inp,sort_keys=True,ensure_ascii=False)].append(case['case_id'])
usage={'experiment_generation_calls':192+sum(r['repairs'] for r in rows),'experiment_input_tokens':sum(r['input_tokens'] for r in rows),'experiment_output_tokens':sum(r['output_tokens'] for r in rows),'cell_seconds_sum':sum(r['seconds'] for r in rows),'v2_generation_seconds_sum':sum(v.get('seconds',0) for v in c['attempts'].values()),'combined_calls':len(c['attempts'])+len(old['attempts']),'combined_input_tokens':sum(v.get('usage',{}).get('prompt_tokens',0) for d in (c,old) for v in d['attempts'].values()),'combined_output_tokens':sum(v.get('usage',{}).get('completion_tokens',0) for d in (c,old) for v in d['attempts'].values()),'currency_cost':None}
secondary={'analysis_type':'secondary descriptive; not replacement of frozen metrics','arms':arms,'factor_matched_pairs':paired,'semantic_failures':failures,'all_arms_same_fence_stripped_object_for_each_case':all(len({json.dumps(objects[cid+'/'+a],sort_keys=True) for a in arms})==1 for cid in cases),'final_outer_fences_removed':fences,'raw_text_changed_in_repaired_cells':changed_repairs,'posthoc_unknown_or_unsafe_outputs':post_unknown,'unique_inputs':len(request_groups),'duplicate_input_groups':[v for v in request_groups.values() if len(v)>1],'all_catalog_paths_safe':all(safe_path(x['path']) for case in cases.values() for x in case['catalog']),'usage':usage,'safety_interpretation':'Frozen safety_gate_applied is an F-configuration flag, not evidence of downstream acceptance gating. No downstream execution. Raw parse failures short-circuit ID/path checks; secondary fence-only inspection finds no ID/path violation. All catalog paths safe; safety generalization unsupported.','environment':{'python':platform.python_version(),'jsonschema':importlib.metadata.version('jsonschema')}}
(OUT/'secondary-analysis.json').write_text(json.dumps(secondary,ensure_ascii=False,indent=2)+'\n')
with (OUT/'arm-summary.csv').open('w') as f:
 cols=['arm_id','strict_success','final_strict_json','final_public_contract','final_semantic_exact','final_semantic_unassessable','posthoc_semantic_success','repairs','input_tokens','output_tokens','mean_total_tokens','mean_seconds','p95_seconds','token_ratio_vs_baseline','mean_latency_ratio_vs_baseline'];w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows({'arm_id':a,**v} for a,v in arms.items())
manifest={'inputs':{},'frozen_scorer_unmodified':True,'analysis_scope':'offline only; no network or generated-code execution'}
for name in ['scorer/score.py','scorer/protocol.py','scorer/oracles.json','scorer/manifest.json','scorer/payload-for-scoring.json','complete/run-probe128/checkpoint.json','complete/preflight-v1/checkpoint.json']:
 manifest['inputs'][name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
(OUT/'analysis-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in secondary.items() if k not in ['arms','factor_matched_pairs']},ensure_ascii=False,indent=2))
